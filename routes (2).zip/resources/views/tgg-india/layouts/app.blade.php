<!DOCTYPE html>
<html lang="en">
<head>
  <title>@yield('title', 'TGG Edge | TGG India Dashboard')</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link rel="icon" href="{{ asset('assets/tgg-india/images/tgg-india-fav.jpg') }}" type="image/x-icon">

  <!-- Fonts and Styles --> 
  <link rel="stylesheet" href="{{ asset('assets/fonts/fonts.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/tgg-india/css/style.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/bootstrap/css/bootstrap.min.css') }}">
  <script src="{{ asset('assets/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <link rel="stylesheet" href="{{ asset('assets/fontawesome/css/all.min.css') }}">
  <link rel="stylesheet" href="{{ asset('assets/tgg-india/css/header-footer.css') }}">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  @if(!request()->routeIs('tgg-india.show') && !request()->routeIs('tgg-india.register.show') && !request()->routeIs('tgg-india.register.show'))
  <link rel="stylesheet" href="{{ asset('chatbot/css/chat-widget.css') }}">
  <script src="{{ asset('chatbot/js/chat-widget.js') }}"></script>
  <script src="{{ asset('chatbot/js/faqs.js') }}"></script>
  <script defer src="https://unpkg.com/alpinejs"></script>
  <!-- <script src="https://unpkg.com/alpinejs" defer></script>  -->
  <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

  @endif


  <!-- Choices.js CSS -->
  <link rel="stylesheet" href="{{ asset('assets/choices/choices.min.css') }}">
</head>

<body style="font-family: 'POPPINS'">
  @include('tgg-india.layouts.includes.header')

  <div class="container-fluid">
    <div class="row">
        @if(isset($is_sidebar) && $is_sidebar === false)
          <div class="col-md-12 tgg-content">
              @yield('content')
          </div>
        @else
        <div class="col-md-3 tgg-sidebar d-none d-lg-block">
          @if( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 1 )
              @include('tgg-india.layouts.includes.admin-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 2)
              @include('tgg-india.layouts.includes.trainer-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 3)
              @include('tgg-india.layouts.includes.member-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 6)
              @include('tgg-india.layouts.includes.freelancer-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 7)
              @include('tgg-india.layouts.includes.co-creator-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 8)
              @include('tgg-india.layouts.includes.facilitator-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) &&  auth('web2')->user()->user_role == 9)
              @include('tgg-india.layouts.includes.spouse-sidebar')
          @else
              @include('tgg-india.layouts.includes.trainer-sidebar')
          @endif
        </div>

        {{-- Removed mobile menu section --}}
        <div class="col-md-9 tgg-content">
            <button class="btn btn-dark d-lg-none mb-2" id="mobileSidebarToggle">
                <i class="fas fa-bars"></i> Menu
            </button>
          @yield('content')
        </div> 
    @endif
    </div>
  </div>

  {{-- ===========================
       MOBILE SIDEBAR (FULLY REMOVED)
       =========================== --}}
@if(isset($is_sidebar) && $is_sidebar !== false)
         
  <div id="mobileSidebar" class="mobile-sidebar d-lg-none">
      <div class="mobile-sidebar-content">
          <button type="button" class="btn-close text-reset mb-2" id="mobileSidebarClose"></button>

          @if( isset(auth('web2')->user()->user_role) && auth('web2')->user()->user_role == 1 )
              @include('tgg-india.layouts.includes.admin-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) && auth('web2')->user()->user_role == 2 )
              @include('tgg-india.layouts.includes.trainer-sidebar')
          @elseif( isset(auth('web2')->user()->user_role) && auth('web2')->user()->user_role == 3 )
               @include('tgg-india.layouts.includes.member-sidebar')
          @else
             @include('tgg-india.layouts.includes.trainer-sidebar') 
          @endif 
      </div>
  </div>
  
@endif




  @include('tgg-india.layouts.includes.footer')


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('mobileSidebar');
            const toggle = document.getElementById('mobileSidebarToggle');
            const close = document.getElementById('mobileSidebarClose');

            if (toggle && sidebar) {
                toggle.addEventListener('click', function() {
                    sidebar.classList.add('active');
                });
            }

            if (close && sidebar) {
                close.addEventListener('click', function() {
                    sidebar.classList.remove('active');
                });
            }
        });
    </script>

  <!-- Choices.js JS -->
  <script src="{{ asset('assets/choices/choices.min.js') }}"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


  <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('select[multiple]').forEach(function (el) {
            new Choices(el, {
                removeItemButton: true,
                placeholderValue: el.getAttribute('placeholder') || 'Select options',
                searchEnabled: true,
            });
        });
    });


    document.addEventListener("DOMContentLoaded", function () {
        const para = document.getElementById("expandWelcome");
        const toggleBtn = document.getElementById("toggleExpandWelcome");

        // Calculate max 8 lines height
        let lineHeight = parseFloat(window.getComputedStyle(para).lineHeight);
        let maxHeight = lineHeight * 8;

        // Show read more only if content overflows
        if (para.scrollHeight > maxHeight) {
            toggleBtn.style.display = "inline-block";
        }

        toggleBtn.addEventListener("click", function () {
            if (para.style.webkitLineClamp === "unset") {
                para.style.webkitLineClamp = "8";
                toggleBtn.innerText = "Read More";
            } else {
                para.style.webkitLineClamp = "unset";
                toggleBtn.innerText = "Read Less";
            }
        });
    });

    document.querySelectorAll('.toggle-pass').forEach(btn => {
        btn.onclick = () => {
            let input = btn.previousElementSibling;
            input.type = input.type === "password" ? "text" : "password";
        };
    });

  </script>

  {{-- CKEditor 5 --}}
  <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/super-build/ckeditor.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.js-ckeditor').forEach(function (el) {
            if (el.dataset.ckeditorInited) return;
            el.dataset.ckeditorInited = '1';

            CKEDITOR.ClassicEditor.create(el, {
                extraPlugins: [ MyCustomUploadAdapterPlugin ],
                removePlugins: [
                    'Base64UploadAdapter','CKBox','CKFinder','CKFinderUploadAdapter','EasyImage',
                    'RealTimeCollaborativeComments','RealTimeCollaborativeTrackChanges',
                    'RealTimeCollaborativeRevisionHistory','PresenceList','Comments',
                    'TrackChanges','TrackChangesData','RevisionHistory','Pagination',
                    'WProofreader','MathType','DocumentOutline','ExportPdf','ExportWord',
                    'TableOfContents','FormatPainter','Template','SlashCommand',
                    'PasteFromOfficeEnhanced'
                ],
                toolbar: [
                    'heading', '|', 'bold', 'italic', 'underline', 'link', '|',
                    'bulletedList', 'numberedList', '|', 'insertTable', 'blockQuote',
                    'imageUpload', 'undo', 'redo', '|', 'sourceEditing'
                ],
                htmlSupport: {
                    allow: [{ name: /.*/, attributes: true, classes: true, styles: true }]
                },
                image: {
                    resizeUnit: '%',
                    resizeOptions: [
                        { name: 'resizeImage:original', label: 'Original', value: null },
                        { name: 'resizeImage:25', label: '25%', value: '25' },
                        { name: 'resizeImage:50', label: '50%', value: '50' },
                        { name: 'resizeImage:75', label: '75%', value: '75' },
                        { name: 'resizeImage:100', label: '100%', value: '100' }
                    ],
                    toolbar: [
                        'imageStyle:inline','imageStyle:block','imageStyle:side','|',
                        'resizeImage','imageTextAlternative'
                    ]
                }
            }).then(editor => {
                editor.editing.view.change(writer => {
                    writer.setStyle('font-size', '13px', editor.editing.view.document.getRoot());
                    writer.setStyle('color', '#000', editor.editing.view.document.getRoot());
                    writer.setStyle('font-family', 'poppins, system-ui, Arial, sans-serif', editor.editing.view.document.getRoot());
                });
                
            }).catch(console.error);
        });
    });

    class UploadAdapter {
        constructor(loader) { this.loader = loader; }
        upload() {
            return this.loader.file.then(file => new Promise((resolve, reject) => {
                const data = new FormData();
                data.append('upload', file);
                data.append('_token', '{{ csrf_token() }}');
                fetch('{{ route('ckeditor.upload') }}', {
                    method: 'POST',
                    body: data
                })
                .then(res => res.json())
                .then(data => {
                    if (data.url) resolve({ default: data.url });
                    else reject(data.error || 'Upload failed');
                })
                .catch(reject);
            }));
        }
        abort() {}
    }
    function MyCustomUploadAdapterPlugin(editor) {
        editor.plugins.get('FileRepository').createUploadAdapter = loader => new UploadAdapter(loader);
    }
  </script>

  @stack('scripts')

</body>
</html>
