<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
          Schema::connection('mysql2')->table('assignments', function (Blueprint $table) {
            $table->unsignedBigInteger('price')->nullable()->after('due_date');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::connection('mysql2')->table('assignments', function (Blueprint $table) {
            $table->dropColumn(['price']);
        });
    }
};
