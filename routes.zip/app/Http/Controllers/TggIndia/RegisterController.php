<?php

namespace App\Http\Controllers\TggIndia;

use App\Http\Controllers\Controller;
use App\Models\AssignmentSecondary;
use App\Models\Incentive;
use App\Models\ModuleInstance;
use App\Models\Payment;
use App\Models\Referral;
use App\Models\User;
use App\Models\UserSecondary;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use App\Traits\RazorpayPaymentTrait;

class RegisterController extends Controller
{
    use RazorpayPaymentTrait;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, $user_type)
    {
        //
        if ($user_type == 'trainer') {
            $user_type = 2;
        } elseif ($user_type == 'members') {
            $user_type = 3;
        } elseif ($user_type == 'admin') {
            $user_type = 1;
        } elseif ($user_type == 'rhm-club') {
            $user_type = 4;
        } elseif ($user_type == 'nomad-community') {
            $user_type = 5;
        } else {
            $user_type = 6;
        }

        $request->validate([
            'name' => 'required|string',
            'age' => 'required|integer',
            'number' => 'required|string',
            'email' => [
                'required',
                'email',
                Rule::unique('mysql2.users', 'email')->where(function ($query) use ($user_type) {
                    return $query->where('user_role', $user_type);
                }),
            ],
            'address' => 'required|string',
            'rhm_number' => 'required'
        ]);

        // Store user
        $user = UserSecondary::create([
            'name' => $request->name,
            'age' => $request->age,
            'project' => $request->project ?? null,
            'phone' => $request->number,
            'email' => $request->email,
            'address' => $request->address,
            'user_role' => $user_type,
            'rhm_number' => $request->rhm_number,
            'password' => Hash::make('default-password'),
            'referral_code' => generateUniqueReferralCode(),
        ]);

        // if ($refCode = $request->query('ref')) {
        //     $referrer = UserSecondary::where('referral_code', $refCode)->first();
        //     if ($referrer && $referrer->id != $user->id) {
        //         Referral::create([
        //             'referrer_id' => $referrer->id,
        //             'referred_id' => $user->id,
        //             'step' => 0
        //         ]);
        //     }
        // }

        // if ($request->has('modules') && is_array($request->modules)) {
        //     foreach ($request->modules as $moduleId) {
        //         ModuleInstance::create([
        //             'module_id' => $moduleId,
        //             'user_id' => $user->id,
        //         ]);
        //     }
        // }

        if ($request->has('modules') && is_array($request->modules)) {
            $modules = $request->modules;
        } else {
            $modules = [];
        }

        if (!in_array(1, $modules)) {
            $modules[] = 1;
        }

        foreach ($modules as $moduleId) {
            ModuleInstance::create([
                'module_id' => $moduleId,
                'user_id'   => $user->id,
            ]);
        }

        return redirect()->route('tgg-india.login')->with('success', 'Registration successful!');
    }

    public function referralStore(Request $request, $user_type)
    {
        $request->validate([
            'name' => 'required|string',
            'age' => 'required|integer',
            'number' => 'required|string',
            'email' => [
                'required',
                'email',
                Rule::unique('mysql2.users', 'email')->where(function ($query) use ($user_type) {
                    return $query->where('user_role', $user_type);
                }),
            ],
            'address' => 'required|string',
            'rhm_number' => 'required'
        ]);

        $amount = 4000;
        $description = 'Registration Payment for TGG India Membership.This covers the one-time joining fee of ₹{$amount} required to become a registered member and access exclusive features, services and resources offered by TGG India.';

       session(['razorpay_key_type' => 'tgg-india']);
        // create order on razorpay
        $order = $this->createRazorpayOrder($amount, 'INR', 'rcpt_' . time(), ['purpose' => $description], 1);

        // store registration data in session until payment verified
        session([
            'pending_registration' => [
                'data' => $request->all(),
                'user_type' => $user_type,
            ],
            'payment.order_id' => $order['id'],
            'payment.amount' => $amount,
            'payment.meta' => [
                'description' => $description,
                'name' => 'TGG India',
                'return_url' => '',
            ]
        ]);

        return view('tgg-india.rozarpay-payments', [
            'razorpayKey' => env('RAZORPAY_KEY'),
            'orderId' => $order['id'],
            'amount' => $amount,
            'name' => 'TGG India',
            'description' => $description,
            'currency' => 'INR',
            'themeColor' => '#033576',
        ]);
    }

    public function verifyPayment(Request $request)
    {
        $payload = $request->all();

        $expectedOrderId = session('payment.order_id');
        $expectedAmount = session('payment.amount');

        $result = $this->validateAndVerifyPayment($payload, $expectedOrderId, $expectedAmount);

        if (!$result['success']) {
            return response()->json(['success' => false, 'error' => $result['error']]);
        }

        $payment = $result['payment'];
        $regData = session('pending_registration.data');
        $userType = session('pending_registration.user_type');

        
        $roleMap = [
            'admin' => 1,
            'trainer' => 2,
            'members' => 3,
            'rhm-club' => 4,
            'nomad-community' => 5,
            'researcher' => 6,
        ];
        $user_type_id = $roleMap[$userType] ?? 3;

        
        $referredUser = UserSecondary::create([
            'name' => $regData['name'],
            'age' => $regData['age'],
            'project' => $regData['project'] ?? null,
            'phone' => $regData['number'],
            'email' => $regData['email'],
            'address' => $regData['address'],
            'user_role' => $user_type_id,
            'rhm_number' => $regData['rhm_number'],
            'password' => Hash::make('default-password'),
            'referral_code' => generateUniqueReferralCode(),
        ]);

       
        $modules = $regData['modules'] ?? [];
        if (!in_array(1, $modules)) {
            $modules[] = 1;
        }
        foreach ($modules as $moduleId) {
            ModuleInstance::create([
                'module_id' => $moduleId,
                'user_id'   => $referredUser->id,
            ]);
        }

        if (!empty($regData['referral_code'])) {
            $referrerUser = UserSecondary::where('referral_code', $regData['referral_code'])->first();
            if ($referrerUser) {
                Referral::create([
                    'referrer_id' => $referrerUser->id,
                    'referred_id' => $referredUser->id,
                    'step' => 0
                ]);
            }
        }

        
          $paymentRecord = Payment::create([
            'payer_id' => $referredUser->id,
            'payer_type' => 'registration',
            'feature_key' => 'registration',
            'amount' => (intval($payment['amount']) / 100),
            'status' => $payment['status'] ?? 'captured',
            'transaction_id' => $payment['id'] ?? null,        
            'payment_method' => $payment['method'] ?? null,  
            'currency' => $payment['currency'] ?? 'INR',
            'meta' => json_encode([
                'order_id' => $payment['order_id'] ?? null,
                'description' => session('payment.meta.description') ?? 'registration',
                'name' => session('payment.meta.name') ?? null,
                'extra' => session('payment.meta.extra') ?? [],
            ]),
            'created_at' => now(),
            'updated_at' => now(),
            'source_id' => $referredUser->id,
            'source_type' => 'UserSecondary',
        ]);

        Incentive::create([
            'title'       => 'Referral Incentive',
            'source_id'   => $referrerUser->id,
            'source_type' => 'registration',
            'target_id'   =>  1,  
            'target_type' => null,
            'description' => 'Incentive for successful registration via referral',
            'reason'      => 'registration_referral',
            'amount'      => 1000,   
            'status'      => 'pending',
        ]);

        session()->forget(['pending_registration', 'payment']);

        return response()->json(['success' => true, 'message' => 'Registration completed successfully!']);
    }


    /**
     * Display the specified resource.
     */
    public function show($user_type)
    {
        $user_types = collect(UserSecondary::$user_types);

        // Find the ID where the name matches (case-insensitive)
        $foundKey = $user_types
            ->search(fn($info) => strcasecmp($info['key'], $user_type) === 0);

        if ($foundKey === false) {
            abort(404);
        }

        return view('tgg-india.register', compact('user_type', 'user_types'));
    }

    public function showReferral($referrer_code)
    {
        $user_type = 'members';
        return view('tgg-india.referral-register', compact('user_type', 'referrer_code'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
