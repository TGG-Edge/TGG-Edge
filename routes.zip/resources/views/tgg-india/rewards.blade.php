@extends('tgg-india.layouts.app')

@section('title', 'Rewards | TGG Meta | TGG India')

@section('content')
<div class="admin-container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-3 trainer-heading">My Rewards</h4>
    </div>
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Reward</th>
                <th>Category</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Value</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($rewards as $reward)
            <tr>
                <td>{{ $reward->title }}</td>
                <td>{{ $reward->category ?? '-' }}</td>
                <td>{!! statusWithColor($reward->status) !!}</td>
                <td>{{ \Carbon\Carbon::parse($reward->created_at)->format('d M Y') }}</td>
                <td>{{ number_format($reward->value, 2) }}</td>
                <td>
                    <a href="#" class="btn btn-primary btn-sm">
                        <i class="fas fa-eye"></i>
                    </a>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-center">No rewards found</td>
            </tr>
            @endforelse
        </tbody>
    </table>
    {{ $rewards->links() }}
</div>
@endsection
