@extends('tgg-india.layouts.app')
@include('tgg-india.layouts.includes.message')

@section('title', 'User Registration | TGG Meta | TGG India')
@php
    $is_sidebar = false;
@endphp
@section('content')
    <div class="container py-4">
        <div class="row g-4">
            {{-- Left Section --}}
            <div class="col-md-6">
                {{-- Registration Info --}}
                <div class="card shadow rounded-4 p-4 mb-4">
                    <h4 class="mb-3">Welcome to TGG Meta Registration</h4>
                    <div class="card shadow rounded-4 mb-4 overflow-hidden">
                        <img src="{{ asset('assets/tgg-india/images/referral-registration-image.png') }}"
                            alt="TGG Registration" class="img-fluid w-100">
                    </div>
                    <p class="text-muted small">
                        This registration is intended for the TGG India community. Trainers can create and share learning
                        modules, while members/users can access and utilize these modules for their growth. Please ensure
                        all details are filled in accurately. Fields marked with * are mandatory.
                    </p>
                </div>
            </div>


            {{-- Right Section (Registration Form) --}}
            <div class="col-md-6">
                {{-- Donation Info --}}
                <div class="card shadow rounded-4 p-4 mb-4">
                    <h5 class="mb-3">Support the Cause</h5>
                    <p class="text-muted small">
                        Contribute to the creation and nurturing of the RHM Center in Wayanad — a sanctuary for
                        responsible human missions and experiential learning.
                    </p>

                    <form action="{{ route('tgg-india.donate.create') }}" method="POST">
                        @csrf

                        <!-- Donation Amount -->
                        <div class="mb-3">
                            <label for="amount" class="form-label">Donation Amount (₹)</label>
                            <input type="number" name="amount" id="amount" class="form-control"
                                placeholder="Enter amount" required>
                        </div>

                        <!-- Donor Name -->
                        <div class="mb-3">
                            <label for="name" class="form-label">Your Name</label>
                            <input type="text" name="name" id="name" class="form-control"
                                placeholder="Enter your full name" required>
                        </div>

                        <!-- Details (Email & Phone) -->
                        <div class="mb-3">
                            <label for="details" class="form-label">Details</label>
                            <textarea name="details" id="details" class="form-control" rows="3"
                                placeholder="Please enter your email and phone number here" required></textarea>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" class="btn btn-success w-100">Donate Now</button>
                    </form>
                </div>

                <div class="card shadow rounded-4 p-4">
                    <h4 class="text-center mb-4">Registration</h4>

                    @if (session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if (session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    @if ($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    @endif

                    <form method="POST"
                        action="{{ route('tgg-india.register.referral.store', [$user_type, 'referral_code' => $referrer_code]) }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Name *</label>
                                <input type="text" class="form-control" name="name" placeholder="Full name" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Age *</label>
                                <input type="number" class="form-control" name="age" placeholder="Your age" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" placeholder="Email" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Phone Number *</label>
                                <input type="text" class="form-control" name="number" placeholder="Mobile number"
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">RHM Registration Number *</label>
                                <input type="text" class="form-control" name="rhm_number" placeholder="If applicable"
                                    required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Address *</label>
                                <textarea class="form-control" name="address" placeholder="Full address" rows="2" required></textarea>
                            </div>

                            @if ($user_type == 'researcher')
                                <div class="col-12">
                                    <label class="form-label">Project (Research Topic Description) *</label>
                                    <textarea class="form-control" name="project" placeholder="Describe your research project here" rows="3"
                                        required></textarea>
                                </div>
                            @endif

                            @if ($user_type != 'admin' && $user_type != 'trainer')
                                <div class="col-12">
                                    <label for="modules" class="form-label">Select Modules</label>
                                    <select name="modules[]" id="modules" class="form-select" multiple>
                                        @foreach (\App\Models\Module::all() as $module)
                                            <option value="{{ $module->id }}"
                                                @if ($module->name == 'INVESTMENT FOR BEGINNERS') selected @endif>{{ $module->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            @endif
                        </div>

                        <button type="submit" class="btn w-100 mt-3 text-white"
                            style="background-color: #033576; border-color: #033576;">Register</button>

                        <p class="text-center mt-3 mb-0" style="font-size: 13px;">
                            Already registered? <a href="{{ route('user.login') }}">Login</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    {{-- Copy referral script --}}
    <script>
        function copyReferral() {
            let input = document.getElementById("referralLink");
            input.select();
            input.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(input.value).then(() => {
                alert("Referral link copied: " + input.value);
            });
        }
    </script>
@endsection
