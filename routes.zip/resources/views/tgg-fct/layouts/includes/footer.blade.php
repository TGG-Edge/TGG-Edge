<div class="footer-container">
  <div class="footer-column">
    <img width="271" height="234" src="https://tggindia.com/wp-content/uploads/2024/12/WhatsApp-Image-2024-12-22-at-12.32.25_d2b8e4ba.jpg" class="attachment-full size-full wp-image-3072" alt="Website Logo">
  </div>

  <div class="footer-column">
    <div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-66d953e animated-slow exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading animated fadeIn" data-id="66d953e" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h3 class="elementor-heading-title elementor-size-default">Contact Us</h3>				</div>
				</div>
				<div class="elementor-element elementor-element-fa79958 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor" data-id="fa79958" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
									<div class="elementor-element elementor-element-23695209 animated elementor-widget elementor-widget-text-editor fadeIn" data-id="23695209" data-settings="{" data-element_type="text-editor.default"><div class="elementor-widget-container"><div class="elementor-text-editor elementor-clearfix"><div class="elementor-element elementor-element-0f337c8 elementor-widget elementor-widget-text-editor" data-id="0f337c8" data-element_type="text-editor.default"><div class="elementor-widget-container"><div class="elementor-text-editor elementor-clearfix"><p>TGG Eco Ventures Pvt. Ltd.&nbsp; #677, 1st Floor, 27th Main 13th Cross, Sector-1, HSR Layout, Bangalore-560102, Karnataka, India</p></div></div></div></div></div></div>								</div>
				</div>
					</div>
  </div>

  <div class="footer-column">
    <div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-65f7f4f animated-slow exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading animated fadeIn" data-id="65f7f4f" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h3 class="elementor-heading-title elementor-size-default">Pages</h3>				</div>
				</div>
				<div class="elementor-element elementor-element-a0ccae4 elementor-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-icon-list" data-id="a0ccae4" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/">

											<span class="elementor-icon-list-text">Home</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/about-us/">

											<span class="elementor-icon-list-text">About Us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/journey-with-tgg/">

											<span class="elementor-icon-list-text">Journey with TGG</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/contact-us/">

											<span class="elementor-icon-list-text">Contact Us</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/terms-conditions-2/">

											<span class="elementor-icon-list-text">Privacy policy</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/terms-conditions-2-2/">

											<span class="elementor-icon-list-text">Shipping &amp; Exchange</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/terms-conditions/">

											<span class="elementor-icon-list-text">Terms &amp; Conditions</span>
											</a>
									</li>
								<li class="elementor-icon-list-item">
											<a href="https://tggindia.com/cancellation-refund/">

											<span class="elementor-icon-list-text">Cancellation and Refund</span>
											</a>
									</li>
						</ul>
						</div>
				</div>
					</div>
  </div>

  <div class="footer-column">
    <div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e44f2ad animated-slow exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading animated fadeIn" data-id="e44f2ad" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeIn&quot;}" data-widget_type="heading.default">
				<div class="elementor-widget-container">
					<h3 class="elementor-heading-title elementor-size-default">Member Login</h3>				</div>
				</div>
				<div class="elementor-element elementor-element-70a9d22 elementor-button-align-stretch exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-login" data-id="70a9d22" data-element_type="widget" data-widget_type="login.default">
				<div class="elementor-widget-container">
							<form class="elementor-login elementor-form" method="post" action="https://tggindia.com/wp-login.php">
			<input type="hidden" name="redirect_to" value="https://tggindia.com/my-account/">
			<div class="elementor-form-fields-wrapper">
				<div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required">
					<label for="user-70a9d22" class="elementor-field-label">Username or Email Address</label>
					<input size="1" type="text" name="log" id="user-70a9d22" placeholder="" class="elementor-field elementor-field-textual elementor-size-sm" fdprocessedid="6buqqq">
				</div>
				<div class="elementor-field-type-text elementor-field-group elementor-column elementor-col-100 elementor-field-required">
					<label for="password-70a9d22" class="elementor-field-label">Password</label>
					<input size="1" type="password" name="pwd" id="password-70a9d22" placeholder="" class="elementor-field elementor-field-textual elementor-size-sm" fdprocessedid="eqnkb">
				</div>

									<div class="elementor-field-type-checkbox elementor-field-group elementor-column elementor-col-100 elementor-remember-me">
						<label for="elementor-login-remember-me">
							<input type="checkbox" id="elementor-login-remember-me" name="rememberme" value="forever">
							Remember Me						</label>
					</div>
				
				<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100">
					<button type="submit" class="elementor-size-sm elementor-button" name="wp-submit" fdprocessedid="8mqzak">
															<span class="elementor-button-text">Log In</span>
												</button>
				</div>

									<div class="elementor-field-group elementor-column elementor-col-100">
																				<a class="elementor-lost-password" href="https://tggindia.com/my-account/lost-password/">
								Lost your password?							</a>
						
											</div>
							</div>
		</form>
						</div>
				</div>
					</div>
</div>
