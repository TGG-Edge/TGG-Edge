document.addEventListener('click', function (e) {

    const question = e.target.closest('.faq-question');

    if (!question) return;

    const id = question.getAttribute('data-id');
    const answer = document.getElementById('faq-answer-' + id);
    const parentItem = question.closest('.faq-item');

    // Toggle active classes
    parentItem.classList.toggle('active');
    answer.classList.toggle('active');

});
